/**
 * You can import your own hybrid (server render + hydration) components below
 * @example

 * @example
 * import 'src/otherFolder/MyOtherComponent';
 */

import './TrainingBYOC';
import './ByocPromo';

// eslint-disable-next-line import/no-anonymous-default-export
export default {};
