# Traefik Proxy

This path contains certificates and configuration for the Traefik
reverse proxy, which is used in container-based Sitecore development
environments. See Sitecore Containers documentation for more information.